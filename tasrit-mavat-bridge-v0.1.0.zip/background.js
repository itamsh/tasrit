// Relays captured mavat documents to a tasrit.vercel.app tab — reuses one if
// already open, otherwise opens one in the background and waits for it to load.
const TASRIT_URL = 'https://tasrit.vercel.app/';
const TASRIT_MATCH = 'https://tasrit.vercel.app/*';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'send-to-tasrit') return;
  (async () => {
    try {
      const tabId = await getOrOpenTasritTab();
      await chrome.tabs.sendMessage(tabId, { type: 'tasrit-import', files: msg.files });
      await chrome.tabs.update(tabId, { active: true });
      sendResponse({ ok: true });
    } catch (e) {
      sendResponse({ ok: false, error: String((e && e.message) || e) });
    }
  })();
  return true; // keep the message channel open for the async response
});

async function getOrOpenTasritTab() {
  const tabs = await chrome.tabs.query({ url: TASRIT_MATCH });
  if (tabs.length) return tabs[0].id;
  const tab = await chrome.tabs.create({ url: TASRIT_URL, active: false });
  await waitForTabComplete(tab.id);
  await new Promise((r) => setTimeout(r, 400)); // let the page's own listener attach
  return tab.id;
}

function waitForTabComplete(tabId) {
  return new Promise((resolve) => {
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}
