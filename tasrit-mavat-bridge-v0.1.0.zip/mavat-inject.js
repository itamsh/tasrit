// MAIN-world hook for mavat.iplan.gov.il (Planning Administration).
//
// mavat gates every document-download API behind reCAPTCHA v3 — a fresh token
// is minted by the page's OWN code only when the user clicks the site's own
// "הורדת קבצים ב-ZIP" control. We never mint or forge a token; we only
// intercept the ZIP the page's own click already legitimately requested,
// instead of letting it save to disk, and hand the bytes to the isolated-world
// panel script via window.postMessage (same-origin, same document).
//
// Declared as a MAIN-world content_script at document_start so the XHR patch
// is in place before the Angular app boots.
(function () {
  if (window.__TASRIT_MAVAT_HOOKED__) return;
  window.__TASRIT_MAVAT_HOOKED__ = true;

  const ZIP_RE = /\/rest\/api\/zipAttacments/i;
  let captureNonce = null; // truthy while the panel wants us to intercept zips

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || typeof e.data !== 'object') return;
    if (e.data.__tasritCmd === 'capture-on') captureNonce = String(e.data.nonce || '1');
    else if (e.data.__tasritCmd === 'capture-off') captureNonce = null;
  });

  // Suppress the native anchor-based save while capturing, so the user doesn't
  // ALSO get a loose file in their Downloads folder (download anchors only —
  // never touches normal page navigation).
  const origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (captureNonce && this.hasAttribute('download')) return;
    return origClick.apply(this, arguments);
  };
  const origDispatch = HTMLAnchorElement.prototype.dispatchEvent;
  HTMLAnchorElement.prototype.dispatchEvent = function (ev) {
    if (captureNonce && this.hasAttribute('download') && ev && ev.type === 'click') return false;
    return origDispatch.apply(this, arguments);
  };

  function cdFilename(cd) {
    if (!cd) return '';
    let m = /filename\*=(?:UTF-8'')?([^;]+)/i.exec(cd);
    if (m) { try { return decodeURIComponent(m[1].trim().replace(/^"|"$/g, '')); } catch {} }
    m = /filename="?([^";]+)"?/i.exec(cd);
    return m ? m[1].trim() : '';
  }

  const OrigXHR = window.XMLHttpRequest;
  function PatchedXHR() {
    const xhr = new OrigXHR();
    let url = '';
    const origOpen = xhr.open;
    xhr.open = function (m, u) { url = u; return origOpen.apply(xhr, arguments); };
    xhr.addEventListener('load', () => {
      try {
        if (!captureNonce || !ZIP_RE.test(url)) return;
        const blob = xhr.response;
        if (!(blob instanceof Blob)) return;
        const name = cdFilename(xhr.getResponseHeader && xhr.getResponseHeader('content-disposition'));
        window.postMessage({ __tasritMavat: 'zip', nonce: captureNonce, name, blob }, location.origin);
      } catch (e) {}
    });
    return xhr;
  }
  PatchedXHR.prototype = OrigXHR.prototype;
  window.XMLHttpRequest = PatchedXHR;
})();
