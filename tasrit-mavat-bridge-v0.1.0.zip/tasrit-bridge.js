// Content script on tasrit.vercel.app — bridges files coming from the
// background service worker into the page itself. Content scripts run in an
// isolated JS world (can't call the page's functions directly), so we hand
// the data off via a DOM CustomEvent, which IS visible to the page's own
// listeners. tasrit_viewer.html listens for 'tasrit-import-files' and routes
// the reconstructed File objects through its normal upload pipeline.
chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.type !== 'tasrit-import') return;
  document.dispatchEvent(new CustomEvent('tasrit-import-files', { detail: { files: msg.files || [] } }));
});
