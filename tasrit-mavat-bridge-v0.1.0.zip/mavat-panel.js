// ISOLATED-world panel for mavat.iplan.gov.il plan pages.
// Finds mavat's OWN per-section "הורדת קבצים ב-ZIP" controls, clicks them
// (the MAIN-world hook in mavat-inject.js intercepts the resulting blob
// instead of saving it to disk), unzips locally, classifies files by
// extension the same way the tasrit app's own upload page does, and sends
// the matches to the tasrit tab via the background service worker.
(function () {
  if (!/^\/SV4\//i.test(location.pathname)) return; // only on a plan page

  const DOC_HEADINGS = ['מסמכי התכנית', 'מסמכי מידע מנהלי', 'נוסחי פרסום', 'התנגדויות'];
  const LIKELY_RE = /נספח|דיגיטל/; // sections most likely to hold Table 5 / the program annex

  function accTitle(el) {
    return (el.textContent || '').replace(/הורדת\s*קבצים[\s\S]*$/, '').replace(/\s+/g, ' ').trim();
  }
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function expandDocSections() {
    for (const want of DOC_HEADINGS) {
      const t = [...document.querySelectorAll('.uk-accordion-title')].find(x => accTitle(x).startsWith(want));
      const li = t && (t.closest('li') || t.parentElement);
      if (t && li && !li.classList.contains('uk-open')) { t.click(); await sleep(400); }
    }
    await sleep(250);
  }
  function downloadSpans() {
    return [...document.querySelectorAll('span.uk-text-float-link')].filter(s => /הורדת\s*קבצים/.test(s.textContent || ''));
  }
  function chainFor(el) {
    const c = [];
    let p = el;
    for (let up = 0; up < 16 && p; up++) {
      p = p.parentElement;
      if (!p) break;
      const h = p.querySelector(':scope > .uk-accordion-title, :scope > a.uk-accordion-title, :scope > .title-c');
      if (h) { const x = accTitle(h); if (x && !c.includes(x)) c.push(x); }
    }
    return c;
  }
  function sectionOf(span) {
    const chain = chainFor(span).reverse();
    return { chain, key: chain.join('␟'), label: chain[chain.length - 1] || '(ללא שם)' };
  }
  function fireClick(node) {
    for (const type of ['pointerdown', 'mousedown', 'mouseup', 'click']) {
      node.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    }
  }
  async function findSections() {
    await expandDocSections();
    const out = []; const seen = new Set();
    for (const span of downloadSpans()) {
      const s = sectionOf(span);
      if (!s.chain.length || seen.has(s.key)) continue;
      seen.add(s.key);
      out.push({ ...s, el: span });
    }
    return out;
  }

  // Capture one section's native ZIP: turn capture-on, click, wait for the
  // MAIN-world hook to post the intercepted blob back, turn capture-off.
  function captureSection(section) {
    return new Promise((resolve) => {
      const nonce = 'tb_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
      let done = false;
      const onMsg = (e) => {
        if (e.source !== window || !e.data || e.data.__tasritMavat !== 'zip' || e.data.nonce !== nonce) return;
        if (done) return; done = true;
        window.removeEventListener('message', onMsg);
        window.postMessage({ __tasritCmd: 'capture-off' }, location.origin);
        resolve({ name: e.data.name || (section.label + '.zip'), blob: e.data.blob });
      };
      window.addEventListener('message', onMsg);
      window.postMessage({ __tasritCmd: 'capture-on', nonce }, location.origin);
      fireClick(section.el);
      setTimeout(() => { // timeout guard — recaptcha/network hiccup
        if (done) return; done = true;
        window.removeEventListener('message', onMsg);
        window.postMessage({ __tasritCmd: 'capture-off' }, location.origin);
        resolve(null);
      }, 15000);
    });
  }

  // Classify a filename the same way the tasrit app's own drop-zone router does.
  function classify(name) {
    const ext = (name.split('.').pop() || '').toLowerCase();
    if (['xls', 'xlsx', 'htm', 'html'].includes(ext)) return { zone: 'table5', label: 'טבלה 5' };
    if (['doc', 'docx'].includes(ext)) return { zone: 'word', label: 'תקנון' };
    if (['pdf', 'json'].includes(ext)) return { zone: 'program', label: 'נספח פרוגרמה' };
    return null;
  }

  async function unzipAndClassify(name, blob) {
    const found = [];
    const lname = name.toLowerCase();
    if (lname.endsWith('.zip')) {
      try {
        const zip = await JSZip.loadAsync(blob);
        for (const [path, entry] of Object.entries(zip.files)) {
          if (entry.dir) continue;
          const fname = path.split('/').pop();
          const cls = classify(fname);
          if (!cls) continue;
          const buf = await entry.async('arraybuffer');
          found.push({ name: fname, zone: cls.zone, zoneLabel: cls.label, buffer: buf });
        }
      } catch (e) { /* not a real zip / corrupt — skip */ }
    } else {
      const cls = classify(name);
      if (cls) found.push({ name, zone: cls.zone, zoneLabel: cls.label, buffer: await blob.arrayBuffer() });
    }
    return found;
  }

  // ── UI ──
  const fab = document.createElement('div');
  fab.id = 'tasrit-bridge-fab';
  fab.textContent = '📤 שלח לתצוגת תשריטים';
  document.documentElement.appendChild(fab);

  const panel = document.createElement('div');
  panel.id = 'tasrit-bridge-panel';
  panel.innerHTML = `
    <div class="tb-hdr"><span>📤 שליחה לתצוגת תשריטים</span><button class="tb-x" id="tb-close">✕</button></div>
    <div class="tb-note">סורק את חלקי המסמכים בעמוד זה ומאתר בהם טבלה 5 / נספח פרוגרמה, בלי לגעת בקבצים שכבר יש לך במחשב.</div>
    <button class="tb-btn secondary" id="tb-scan">🔍 סרוק מסמכים בעמוד</button>
    <div class="tb-list" id="tb-sections"></div>
    <button class="tb-btn" id="tb-send" disabled>שלח מסמכים שנבחרו</button>
    <div class="tb-status" id="tb-status"></div>
  `;
  document.documentElement.appendChild(panel);

  let sections = [];
  fab.onclick = () => panel.classList.toggle('vis');
  panel.querySelector('#tb-close').onclick = () => panel.classList.remove('vis');

  panel.querySelector('#tb-scan').onclick = async () => {
    setStatus('סורק…');
    sections = await findSections();
    const list = panel.querySelector('#tb-sections');
    list.innerHTML = sections.length ? sections.map((s, i) => `
      <div class="tb-item">
        <input type="checkbox" id="tb-sec-${i}" ${LIKELY_RE.test(s.label) ? 'checked' : ''}>
        <label for="tb-sec-${i}">${escapeHtml(s.chain.join(' ‹ '))}</label>
      </div>`).join('') : '<div class="tb-status">לא נמצאו קטגוריות להורדה בעמוד זה.</div>';
    panel.querySelector('#tb-send').disabled = !sections.length;
    setStatus(sections.length ? `נמצאו ${sections.length} קטגוריות. הקטגוריות המסומנות מסומנות לפי ניחוש — אפשר לשנות.` : '');
  };

  panel.querySelector('#tb-send').onclick = async () => {
    const checked = sections.filter((s, i) => panel.querySelector('#tb-sec-' + i)?.checked);
    if (!checked.length) { setStatus('לא נבחרה אף קטגוריה.'); return; }
    panel.querySelector('#tb-send').disabled = true;
    const allFiles = [];
    for (let i = 0; i < checked.length; i++) {
      setStatus(`מוריד "${checked[i].label}"… (${i + 1}/${checked.length})`);
      const res = await captureSection(checked[i]);
      if (!res) { setStatus(`נכשל בהורדת "${checked[i].label}" — ייתכן שנדרש רענון עמוד (F5).`); continue; }
      const cls = await unzipAndClassify(res.name, res.blob);
      allFiles.push(...cls);
      await sleep(300);
    }
    if (!allFiles.length) {
      setStatus('לא נמצאו קבצי טבלה 5 / נספח פרוגרמה בקטגוריות שנבחרו.');
      panel.querySelector('#tb-send').disabled = false;
      return;
    }
    setStatus(`נמצאו ${allFiles.length} קבצים רלוונטיים. שולח לתצוגת התשריטים…`);
    chrome.runtime.sendMessage({
      type: 'send-to-tasrit',
      files: allFiles.map(f => ({ name: f.name, type: '', buffer: f.buffer }))
    }, (resp) => {
      panel.querySelector('#tb-send').disabled = false;
      if (chrome.runtime.lastError) { setStatus('שגיאה: ' + chrome.runtime.lastError.message); return; }
      if (resp && resp.ok) {
        setStatus('✓ נשלח! עבור/י ללשונית תצוגת התשריטים — ' +
          allFiles.map(f => f.zoneLabel).filter((v, i, a) => a.indexOf(v) === i).join(', '));
      } else {
        setStatus('שגיאה בשליחה: ' + (resp && resp.error || 'לא ידוע'));
      }
    });
  };

  function setStatus(t) { panel.querySelector('#tb-status').textContent = t; }
  function escapeHtml(s) { return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
})();
