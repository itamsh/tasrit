// MAIN-world hook for mavat.iplan.gov.il (Planning Administration).
//
// mavat gates every document-download API behind reCAPTCHA v3 — a fresh token
// is minted by the page's OWN code only when the user (or our panel, on the
// user's explicit request) clicks the site's own download control. We never
// mint or forge a token; we only intercept the file the page's own click
// already legitimately requested, instead of letting it save to disk / open a
// tab, and hand the bytes to the isolated-world panel script via
// window.postMessage (same-origin, same document).
//
// Two download APIs are captured:
//   /rest/api/zipAttacments  — a whole section as ZIP ("הורדת קבצים ב ZIP")
//   /rest/api/Attacments/?…  — a single file (the file icon on a document row)
//
// Declared as a MAIN-world content_script at document_start so the XHR patch
// is in place before the Angular app boots.
(function () {
  if (window.__TASRIT_MAVAT_HOOKED__) return;
  window.__TASRIT_MAVAT_HOOKED__ = true;

  const DL_RE = /\/rest\/api\/(zipAttacments|Attacments)\b/i;
  let captureNonce = null; // truthy while the panel wants us to intercept downloads

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || typeof e.data !== 'object') return;
    if (e.data.__tasritCmd === 'capture-on') captureNonce = String(e.data.nonce || '1');
    else if (e.data.__tasritCmd === 'capture-off') captureNonce = null;
  });

  // While capturing, suppress the page's own "save" / "open in new tab" of the
  // same bytes, so the user doesn't get a loose file or a stray tab. Only
  // download/blob anchors and window.open are affected — never normal navigation.
  const isSaveAnchor = (a) => a.hasAttribute('download') || /^blob:/i.test(a.getAttribute('href') || '');
  const origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (captureNonce && isSaveAnchor(this)) return;
    return origClick.apply(this, arguments);
  };
  const origDispatch = HTMLAnchorElement.prototype.dispatchEvent;
  HTMLAnchorElement.prototype.dispatchEvent = function (ev) {
    if (captureNonce && isSaveAnchor(this) && ev && ev.type === 'click') return false;
    return origDispatch.apply(this, arguments);
  };
  const origOpen = window.open;
  window.open = function () {
    if (captureNonce) return null;
    return origOpen.apply(window, arguments);
  };

  function cdFilename(cd) {
    if (!cd) return '';
    let m = /filename\*=(?:UTF-8'')?([^;]+)/i.exec(cd);
    if (m) { try { return decodeURIComponent(m[1].trim().replace(/^"|"$/g, '')); } catch {} }
    // mavat's own parsing (main.js GetAttachment): the value is URL-encoded and itself
    // contains "filename=<real name>" after decoding; '+' stands for a space.
    m = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/i.exec(cd);
    if (!m || !m[1]) return '';
    let v = m[1].replace(/^["']|["']$/g, '');
    try { v = decodeURIComponent(v); } catch {}
    if (/filename=/i.test(v)) v = v.split(/filename=/i)[1];
    v = v.split('+').join(' ').replace(/^["']|["']$/g, '').trim();
    return /^attachment$/i.test(v) ? '' : v;
  }
  function fnParam(url) {
    try { return new URL(url, location.href).searchParams.get('fn') || ''; } catch { return ''; }
  }

  const OrigXHR = window.XMLHttpRequest;
  function PatchedXHR() {
    const xhr = new OrigXHR();
    let url = '';
    const origXOpen = xhr.open;
    xhr.open = function (m, u) { url = String(u || ''); return origXOpen.apply(xhr, arguments); };
    // download progress → panel (→ tasrit app progress bar)
    xhr.addEventListener('progress', (ev) => {
      try {
        if (!captureNonce || !DL_RE.test(url)) return;
        window.postMessage({ __tasritMavat: 'progress', nonce: captureNonce, loaded: ev.loaded, total: ev.lengthComputable ? ev.total : 0 }, location.origin);
      } catch (e) {}
    });
    xhr.addEventListener('load', () => {
      try {
        if (!captureNonce || !DL_RE.test(url)) return;
        const blob = xhr.response;
        if (!(blob instanceof Blob)) return;
        const name = cdFilename(xhr.getResponseHeader && xhr.getResponseHeader('content-disposition')) || fnParam(url);
        window.postMessage({ __tasritMavat: 'zip', nonce: captureNonce, name, blob, kind: /zipAttacments/i.test(url) ? 'zip' : 'file' }, location.origin);
      } catch (e) {}
    });
    return xhr;
  }
  PatchedXHR.prototype = OrigXHR.prototype;
  window.XMLHttpRequest = PatchedXHR;
})();
