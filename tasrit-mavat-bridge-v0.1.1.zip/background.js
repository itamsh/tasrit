// Relays captured mavat documents to a tasrit.vercel.app tab — reuses one if
// already open, otherwise opens one in the background and waits for it to load.
const TASRIT_URL = 'https://tasrit.vercel.app/';
const TASRIT_MATCH = 'https://tasrit.vercel.app/*';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'send-to-tasrit') return;
  (async () => {
    try {
      const tabId = await getOrOpenTasritTab();
      await sendWithRetry(tabId, { type: 'tasrit-import', files: msg.files });
      await chrome.tabs.update(tabId, { active: true });
      sendResponse({ ok: true });
    } catch (e) {
      sendResponse({ ok: false, error: String((e && e.message) || e) });
    }
  })();
  return true; // keep the message channel open for the async response
});

async function getOrOpenTasritTab() {
  const tabs = await chrome.tabs.query({ url: TASRIT_MATCH });
  if (tabs.length) return tabs[0].id;
  const tab = await chrome.tabs.create({ url: TASRIT_URL, active: false });
  await waitForTabComplete(tab.id);
  return tab.id;
}

function waitForTabComplete(tabId) {
  return new Promise((resolve) => {
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// The tasrit app is a heavy single-file page: the tab's network "complete"
// status fires well before its large inline script finishes running and
// tasrit-bridge.js's message listener is actually live (same applies to a
// tab that was reused but is a slow/discarded background tab). Retry instead
// of guessing a fixed delay — up to ~4s total, which comfortably covers a
// slow load without hanging forever on a truly dead tab.
async function sendWithRetry(tabId, message, tries = 10, delayMs = 400) {
  let lastErr;
  for (let i = 0; i < tries; i++) {
    try {
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (e) {
      lastErr = e;
      await new Promise((r) => setTimeout(r, delayMs));
    }
  }
  throw lastErr || new Error('שליחה נכשלה');
}
