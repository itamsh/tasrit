// אבחון: למה התוסף לא נכנס לעמוד? בודק הרשאות לאתר, האם סקריפט התוסף כבר בעמוד, ומנסה להזריק אותו
// (activeTab: לחיצה על סמל התוסף נותנת לו גישה זמנית ללשונית הנוכחית — לפעמים עוקף חסימה של "בלחיצה בלבד").
const ALLOWED = ['https://tasrit.vercel.app/', 'http://localhost', 'https://mavat.iplan.gov.il/'];
const $ = id => document.getElementById(id);
const lines = []; // לדוח
function add(ok, text, sub) {
  const cls = ok === true ? 'ok' : ok === false ? 'bad' : 'na', ic = ok === true ? '✓' : ok === false ? '✕' : '•';
  $('checks').insertAdjacentHTML('beforeend', `<div class="row"><span class="ic ${cls}">${ic}</span><div><span class="${cls}">${text}</span>${sub ? `<span class="sub">${sub}</span>` : ''}</div></div>`);
  lines.push(`${ic} ${text}${sub ? ' — ' + sub : ''}`);
}
const tabInfo = () => new Promise(r => chrome.tabs.query({ active: true, currentWindow: true }, t => r(t && t[0])));
const probe = () => ({ attr: document.documentElement.getAttribute('data-tasrit-bridge'), href: location.href });

async function run() {
  $('checks').textContent = ''; lines.length = 0;
  const man = chrome.runtime.getManifest();
  $('ver').textContent = `גרסה ${man.version} · מזהה ${chrome.runtime.id}`;
  lines.push(`גרסה ${man.version} · מזהה ${chrome.runtime.id}`);
  const tab = await tabInfo();
  if (!tab || !tab.url) { add(null, 'לא ניתן לקרוא את הלשונית הנוכחית'); return; }
  let u; try { u = new URL(tab.url); } catch (e) { add(null, 'כתובת לא תקינה'); return; }
  lines.push('לשונית: ' + tab.url);
  const onApp = u.origin === 'https://tasrit.vercel.app' || u.hostname === 'localhost';
  const onMavat = u.origin === 'https://mavat.iplan.gov.il';
  if (!onApp && !onMavat) {
    add(null, 'פתחו את התוסף בעמוד הממשק (tasrit.vercel.app) או בעמוד תוכנית ב"מידע תכנוני"', u.origin);
    return;
  }
  add(true, onApp ? 'עמוד הממשק' : 'עמוד "מידע תכנוני"', u.origin);
  // 1. הרשאה לאתר
  let perm = null;
  try { perm = await chrome.permissions.contains({ origins: [u.origin + '/*'] }); } catch (e) {}
  add(perm, perm ? 'יש לתוסף הרשאה לאתר הזה' : 'אין לתוסף הרשאה לאתר הזה', perm ? '' : 'ייתכן שהדפדפן או הארגון מגבילים גישה לאתר');
  // 2. האם הסקריפט של התוסף כבר בעמוד
  let present = null, detail = '';
  try {
    const r = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: probe });
    present = !!(r && r[0] && r[0].result && r[0].result.attr);
    detail = present ? 'גרסה ' + r[0].result.attr : 'הסימן data-tasrit-bridge לא נמצא בעמוד';
  } catch (e) {
    present = false; detail = String(e && e.message || e);
    add(false, 'אין גישה לעמוד (בדיקת סקריפט נכשלה)', detail);
    const pol = /policy|ExtensionsSettings|blocked|administrator/i.test(detail);
    $('checks').insertAdjacentHTML('beforeend', `<div class="hint">${pol ? '<b>זו חסימה של הארגון</b> (מדיניות הדפדפן). צריך שצוות המחשוב יאשר את התוסף — ר׳ הנוסח שהוכן.' : 'הדפדפן לא מאפשר לתוסף לגשת לעמוד הזה. נסו ללחוץ על הכפתור למטה, או לרענן (Ctrl+F5) ולנסות שוב.'}</div>`);
    return;
  }
  add(present, present ? 'התוסף פעיל בעמוד' : 'התוסף עדיין לא נכנס לעמוד', detail);
  if (!present && onApp) $('checks').insertAdjacentHTML('beforeend', '<div class="hint">לחצו על "נסה להפעיל" — זה מזריק את התוסף ידנית לעמוד הזה.</div>');
}

$('inject').onclick = async () => {
  const tab = await tabInfo(); if (!tab) return;
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['tasrit-bridge.js'] });
  } catch (e) { $('checks').insertAdjacentHTML('beforeend', `<div class="row"><span class="ic bad">✕</span><div class="bad">ההזרקה נכשלה<span class="sub">${String(e && e.message || e)}</span></div></div>`); lines.push('הזרקה נכשלה: ' + (e && e.message || e)); return; }
  await run();
};
$('copy').onclick = () => { const t = $('report'); t.style.display = 'block'; t.value = lines.join('\n'); t.select(); try { document.execCommand('copy'); } catch (e) {} };
run();
