// Service worker — two flows:
//
// 1. send-to-tasrit (user is on a mavat plan page and presses "שלח"):
//    relay captured documents to a tasrit tab — reuse one if open, else open one.
//
// 2. mavat-fetch (user loaded a plan BY NUMBER in the tasrit app, v0.2.0):
//    open that plan's mavat page in a background tab, ask the panel script there
//    to press mavat's own Table 5 download control, return the file to the
//    requesting tasrit tab, and close the mavat tab.
const TASRIT_URL = 'https://tasrit.vercel.app/';
const TASRIT_MATCH = 'https://tasrit.vercel.app/*';
const MAVAT_PLAN_RE = /^https:\/\/mavat\.iplan\.gov\.il\/SV4\/\d+\/\d+\/\d+/;

// ── 0.3.9: הזרקה גיבוי ──
// במחשב המשרד (Chrome מנוהל) הסקריפטים המוצהרים ב-manifest לא נכנסו לעמודים, אף שיש לתוסף הרשאה לאתרים וההזרקה התכנותית עובדת.
// לכן ה-background מזריק בעצמו: לעמוד הממשק (tasrit-bridge.js) ולעמוד תוכנית ב-mavat (הוק MAIN + jszip + הפאנל).
// כל הסקריפטים מוגנים מפני הרצה כפולה, כך שאם גם ההצהרה עבדה — אין נזק.
async function ensureBridgeInjected(tabId) {
  try {
    const r = await chrome.scripting.executeScript({ target: { tabId }, func: () => !!window.__tasritBridgeLoaded });
    if (r && r[0] && r[0].result) return true;
    await chrome.scripting.executeScript({ target: { tabId }, files: ['tasrit-bridge.js'] });
    return true;
  } catch (e) { return false; }
}
async function ensureMavatInjected(tabId) {
  try {
    const h = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: () => !!window.__TASRIT_MAVAT_HOOKED__ });
    if (!(h && h[0] && h[0].result)) await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', files: ['mavat-inject.js'] });
    const p = await chrome.scripting.executeScript({ target: { tabId }, func: () => !!window.__tasritPanelLoaded });
    if (!(p && p[0] && p[0].result)) await chrome.scripting.executeScript({ target: { tabId }, files: ['jszip.min.js', 'mavat-panel.js'] });
    return true;
  } catch (e) { return false; }
}
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status !== 'complete' || !tab || !tab.url) return;
  if (tab.url.startsWith(TASRIT_URL)) ensureBridgeInjected(tabId);
});
function injectIntoOpenTabs() {
  chrome.tabs.query({ url: TASRIT_MATCH }, (tabs) => { (tabs || []).forEach((t) => ensureBridgeInjected(t.id)); });
}
chrome.runtime.onInstalled.addListener(injectIntoOpenTabs);
chrome.runtime.onStartup.addListener(injectIntoOpenTabs);

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  if (msg.type === 'send-to-tasrit') {
    (async () => {
      try {
        const tabId = await getOrOpenTasritTab();
        await sendWithRetry(tabId, { type: 'tasrit-import', files: msg.files });
        await chrome.tabs.update(tabId, { active: true });
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: String((e && e.message) || e) });
      }
    })();
    return true; // async response
  }
  if (msg.type === 'mavat-fetch') {
    fetchFromMavat(msg, sender).then(sendResponse, (e) => sendResponse({ ok: false, stage: 'error', error: String((e && e.message) || e) }));
    return true;
  }
  if (msg.type === 'auto-progress' && sender.tab) { // from the mavat panel → relay to the requesting tasrit tab
    const job = JOBS.get(sender.tab.id);
    if (job) relayProgress(job, { stage: 'doc', doc: msg.doc, docs: msg.docs, kind: msg.kind, phase: msg.phase, frac: msg.frac });
    return;
  }
  if (msg.type === 'auto-partial' && sender.tab) { // one document finished — keep it even if a later one stalls
    const job = JOBS.get(sender.tab.id);
    if (job) {
      job.files.push(...(msg.files || []));
      job.results[msg.kind] = msg.result;
      job.trace = msg.trace || job.trace;
    }
    return;
  }
  if (msg.type === 'ping') { sendResponse({ ok: true, version: chrome.runtime.getManifest().version }); return; }
});

// mavat tab id → {requester tab id, reqId} — for progress relaying
const JOBS = new Map();
function relayProgress(job, p) {
  chrome.tabs.sendMessage(job.requester, Object.assign({ type: 'tasrit-progress', reqId: job.reqId }, p)).catch(() => {});
}

async function fetchFromMavat(msg, sender) {
  const url = String(msg.url || '');
  if (!MAVAT_PLAN_RE.test(url)) return { ok: false, stage: 'url', error: 'קישור לא תקין לעמוד תוכנית ב"מידע תכנוני"' };
  let tabId = null;
  const docs = msg.docs || ['t5'];
  const job = { requester: sender && sender.tab ? sender.tab.id : null, reqId: msg.reqId || '', files: [], results: {}, trace: [] };
  try {
    const tab = await chrome.tabs.create({ url, active: false });
    tabId = tab.id;
    JOBS.set(tabId, job);
    if (job.requester != null) relayProgress(job, { stage: 'open' });
    await waitForTabComplete(tabId, 45000);
    await ensureMavatInjected(tabId); // גיבוי: אם הסקריפטים המוצהרים לא נכנסו לעמוד
    if (job.requester != null) relayProgress(job, { stage: 'page' });
    // The Angular app keeps rendering after 'complete' — the panel script waits
    // for the documents tree itself; here we only wait for its listener to be live.
    // Each document has its own 90s limit in the panel; this is only a safety net.
    try {
      const res = await withTimeout(
        sendWithRetry(tabId, { type: 'auto-fetch', docs, planLabel: msg.planLabel || '', checkOnly: !!msg.checkOnly }, 40, 500),
        60000 + docs.length * 95000 + (docs.includes('binui') ? 220000 : 0), 'תם הזמן הכולל');
      return res || { ok: false, stage: 'error', error: 'לא התקבלה תשובה מעמוד התוכנית' };
    } catch (e) {
      // return whatever finished, and say where it got stuck
      const last = job.trace[job.trace.length - 1] || (job.trace.length ? '' : 'עמוד התוכנית לא הגיב לבקשה');
      for (const k of docs) if (!job.results[k]) job.results[k] = { ok: false, error: `${String((e && e.message) || e)} — שלב אחרון: ${last}` };
      return { ok: job.files.length > 0, files: job.files, results: job.results, trace: job.trace,
        error: job.files.length ? '' : String((e && e.message) || e) };
    }
  } finally {
    if (tabId != null) { JOBS.delete(tabId); try { await chrome.tabs.remove(tabId); } catch (e) {} }
  }
}

async function getOrOpenTasritTab() {
  const tabs = await chrome.tabs.query({ url: TASRIT_MATCH });
  if (tabs.length) return tabs[0].id;
  const tab = await chrome.tabs.create({ url: TASRIT_URL, active: false });
  await waitForTabComplete(tab.id);
  return tab.id;
}

function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    let timer = null;
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') done();
    }
    function done() {
      chrome.tabs.onUpdated.removeListener(listener);
      if (timer) clearTimeout(timer);
      resolve();
    }
    chrome.tabs.onUpdated.addListener(listener);
    if (timeoutMs) timer = setTimeout(done, timeoutMs); // proceed anyway; retries cover the rest
  });
}

function withTimeout(p, ms, msg) {
  return Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error(msg)), ms))]);
}

// Heavy pages (tasrit's single-file app, mavat's Angular app): the tab's network
// "complete" fires before the content script's listener is live. Retry instead
// of guessing a fixed delay.
async function sendWithRetry(tabId, message, tries = 10, delayMs = 400) {
  let lastErr;
  for (let i = 0; i < tries; i++) {
    try {
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (e) {
      lastErr = e;
      await new Promise((r) => setTimeout(r, delayMs));
    }
  }
  throw lastErr || new Error('שליחה נכשלה');
}
