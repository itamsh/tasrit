// Content script on the tasrit app — bridges between the page and the
// extension. Content scripts run in an isolated JS world (can't call the
// page's functions directly), so we talk to the page through DOM events whose
// `detail` holds only plain strings/JSON (files as base64) — that crosses the
// world boundary reliably.
//
//   page ← 'tasrit-import-files'   {files:[{name,type,b64}]}   (user pressed "שלח" on a mavat page)
//   page → 'tasrit-mavat-request'  {reqId,url,docs,planLabel}  (app loaded a plan by number)
//   page ← 'tasrit-mavat-response' {reqId,ok,files,error,stage}
//
// Presence is announced on <html data-tasrit-bridge="version"> so the app can
// offer "load Table 5 too" only when the extension is installed.
(function () {
  // 0.3.11: במחשב ארגוני (Chrome 155 מנוהל) הסקריפט רץ, אבל הסימן על <html> נמחק/לא נשמר — והממשק זיהה "לא מותקן".
  // לכן התוסף מודיע על עצמו בכמה ערוצים, והממשק מזהה אותו לפי כל אחד מהם: (א) מאפיין על <html>, (ב) תג <meta>,
  // (ג) אירוע tasrit-bridge-ready, (ד) window.postMessage. הממשק גם שולח "פינג" (אירוע/הודעה) והתוסף עונה.
  const VERSION = chrome.runtime.getManifest().version;
  function announce() {
    try { document.documentElement.setAttribute('data-tasrit-bridge', VERSION); } catch (e) {}
    try {
      let m = document.querySelector('meta[name="tasrit-bridge"]');
      if (!m) { m = document.createElement('meta'); m.name = 'tasrit-bridge'; (document.head || document.documentElement).appendChild(m); }
      m.content = VERSION;
    } catch (e) {}
    try { document.dispatchEvent(new CustomEvent('tasrit-bridge-ready', { detail: JSON.stringify({ version: VERSION }) })); } catch (e) {}
    try { window.postMessage({ __tasritBridge: true, version: VERSION }, location.origin); } catch (e) {}
  }
  if (window.__tasritBridgeLoaded) { if (window.__tasritBridgeAnnounce) window.__tasritBridgeAnnounce(); return; } // הוזרק שוב — רק מכריזים מחדש
  window.__tasritBridgeLoaded = true;
  window.__tasritBridgeAnnounce = announce;
  announce();
  document.addEventListener('tasrit-bridge-ping', announce);
  window.addEventListener('message', (e) => { if (e.source === window && e.data && e.data.__tasritBridgePing) announce(); });

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg) return;
    if (msg.type === 'tasrit-import')
      document.dispatchEvent(new CustomEvent('tasrit-import-files', { detail: JSON.stringify({ files: msg.files || [] }) }));
    else if (msg.type === 'tasrit-progress') // מהתוסף: שלב/אחוז הורדה ← פס ההתקדמות בממשק
      document.dispatchEvent(new CustomEvent('tasrit-mavat-progress', { detail: JSON.stringify(msg) }));
  });

  document.addEventListener('tasrit-mavat-request', (e) => {
    let req = {};
    try { req = typeof e.detail === 'string' ? JSON.parse(e.detail) : (e.detail || {}); } catch (err) {}
    const reply = (obj) => document.dispatchEvent(new CustomEvent('tasrit-mavat-response',
      { detail: JSON.stringify(Object.assign({ reqId: req.reqId }, obj)) }));
    try {
      chrome.runtime.sendMessage({ type: 'mavat-fetch', url: req.url, docs: req.docs, planLabel: req.planLabel, reqId: req.reqId, checkOnly: !!req.checkOnly }, (resp) => {
        if (chrome.runtime.lastError) { reply({ ok: false, stage: 'extension', error: chrome.runtime.lastError.message }); return; }
        reply(resp || { ok: false, error: 'אין תשובה מהתוסף' });
      });
    } catch (err) {
      // extension was reloaded/updated while this page stayed open
      reply({ ok: false, stage: 'extension', error: 'התוסף עודכן — רעננו את העמוד (F5) ונסו שוב' });
    }
  });
})();
