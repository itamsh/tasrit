// אבחון: למה התוסף לא נכנס לעמוד? בודק הרשאות, האם הסקריפט כבר בעמוד, מנסה להזריק אותו, ומראה יומן מה-background.
const $ = id => document.getElementById(id);
const lines = []; // לדוח
function add(ok, text, sub) {
  const cls = ok === true ? 'ok' : ok === false ? 'bad' : 'na', ic = ok === true ? '✓' : ok === false ? '✕' : '•';
  $('checks').insertAdjacentHTML('beforeend', `<div class="row"><span class="ic ${cls}">${ic}</span><div><span class="${cls}">${text}</span>${sub ? `<span class="sub">${sub}</span>` : ''}</div></div>`);
  lines.push(`${ic} ${text}${sub ? ' — ' + sub : ''}`);
}
const tabInfo = () => new Promise(r => chrome.tabs.query({ active: true, currentWindow: true }, t => r(t && t[0])));
const probe = () => ({ attr: document.documentElement.getAttribute('data-tasrit-bridge'), loaded: !!window.__tasritBridgeLoaded, ready: document.readyState });
const errText = e => String((e && e.message) || e);
const chromeVer = () => { const m = /Chrome\/([\d.]+)/.exec(navigator.userAgent); return m ? m[1] : navigator.userAgent; };
const probeMain = () => ({ attr: document.documentElement.getAttribute('data-tasrit-bridge'), meta: (document.querySelector('meta[name="tasrit-bridge"]') || {}).content || null, seen: window.__tasritBridgeSeen || null, appSees: (typeof window._bridgeVersion === 'function') ? (window._bridgeVersion() || '') : 'אין פונקציה', appVer: ((document.querySelector('.app-version') || {}).textContent || ''), appRan: typeof window.loadPlanByNumber, scripts: document.scripts.length });
async function runMain(tabId) {
  const r = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: probeMain });
  return r && r[0] && r[0].result;
}
async function runProbe(tabId) {
  const r = await chrome.scripting.executeScript({ target: { tabId }, func: probe });
  return r && r[0] && r[0].result;
}

async function run(autoInject) {
  $('checks').textContent = ''; lines.length = 0;
  const man = chrome.runtime.getManifest();
  $('ver').textContent = `גרסה ${man.version} · מזהה ${chrome.runtime.id}`;
  lines.push(`גרסה ${man.version} · מזהה ${chrome.runtime.id} · Chrome ${chromeVer()}`);
  const tab = await tabInfo();
  if (!tab || !tab.url) { add(null, 'לא ניתן לקרוא את הלשונית הנוכחית'); return; }
  let u; try { u = new URL(tab.url); } catch (e) { add(null, 'כתובת לא תקינה'); return; }
  lines.push('לשונית: ' + tab.url);
  const onApp = u.origin === 'https://tasrit.vercel.app' || u.hostname === 'localhost';
  const onMavat = u.origin === 'https://mavat.iplan.gov.il';
  if (!onApp && !onMavat) { add(null, 'פתחו את התוסף בעמוד הממשק (tasrit.vercel.app) או בעמוד תוכנית ב"מידע תכנוני"', u.origin); return; }
  add(true, onApp ? 'עמוד הממשק' : 'עמוד "מידע תכנוני"', u.origin);
  add(null, 'גרסת Chrome ' + chromeVer());
  let perm = null;
  try { perm = await chrome.permissions.contains({ origins: [u.origin + '/*'] }); } catch (e) {}
  add(perm, perm ? 'יש לתוסף הרשאה לאתר הזה' : 'אין לתוסף הרשאה לאתר הזה');
  // רישום סקריפטים דינמיים
  try { const reg = await chrome.scripting.getRegisteredContentScripts(); add(null, 'סקריפטים רשומים: ' + (reg.map(x => x.id).join(', ') || 'אין')); }
  catch (e) { add(null, 'קריאת הסקריפטים הרשומים נכשלה', errText(e)); }
  // 1. מה בעמוד עכשיו
  let before;
  try { before = await runProbe(tab.id); }
  catch (e) {
    add(false, 'אין גישה לעמוד (בדיקת סקריפט נכשלה)', errText(e));
    const pol = /policy|ExtensionsSettings|blocked|administrator/i.test(errText(e));
    $('checks').insertAdjacentHTML('beforeend', `<div class="hint">${pol ? '<b>זו חסימה של הארגון</b> (מדיניות הדפדפן). צריך שצוות המחשוב יאשר את התוסף.' : 'הדפדפן לא מאפשר לתוסף לגשת לעמוד הזה.'}</div>`);
    await addBgLog(); return;
  }
  const present = !!(before && before.attr);
  add(present, present ? 'התוסף פעיל בעמוד (גרסה ' + before.attr + ')' : 'התוסף עדיין לא נכנס לעמוד',
    `סימן בעמוד: ${before && before.attr || 'אין'} · דגל הסקריפט: ${before && before.loaded ? 'כן' : 'לא'} · מצב העמוד: ${before && before.ready}`);
  // 2. ניסיון הזרקה (אוטומטי בפתיחה, או בלחיצה)
  if (!present && onApp && autoInject) {
    try {
      const inj = await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['tasrit-bridge.js'] });
      add(null, 'הזרקה ידנית הסתיימה', 'תוצאה: ' + JSON.stringify(inj && inj.map(x => ({ frame: x.frameId, result: x.result })) ).slice(0, 120));
    } catch (e) { add(false, 'ההזרקה הידנית נכשלה', errText(e)); }
    try {
      const after = await runProbe(tab.id);
      const ok = !!(after && after.attr);
      add(ok, ok ? 'אחרי ההזרקה: התוסף נכנס לעמוד ✓ (גרסה ' + after.attr + ')' : 'אחרי ההזרקה: עדיין לא נכנס', `סימן: ${after && after.attr || 'אין'} · דגל: ${after && after.loaded ? 'כן' : 'לא'}`);
      if (ok) $('checks').insertAdjacentHTML('beforeend', '<div class="hint">התוסף עובד עכשיו בעמוד הזה. אם הממשק עדיין לא מזהה אותו — לרענן את העמוד פעם אחת ולפתוח שוב את החלון הזה.</div>');
    } catch (e) { add(false, 'הבדיקה אחרי ההזרקה נכשלה', errText(e)); }
  }
  // מה הממשק עצמו רואה (עולם MAIN) — זה מה שקובע אם "התוסף מותקן" באתר
  try {
    let mn = await runMain(tab.id);
    if (mn && !mn.appSees) { await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => { document.dispatchEvent(new CustomEvent('tasrit-bridge-ping')); window.postMessage({ __tasritBridgePing: true }, location.origin); } }); await new Promise(r => setTimeout(r, 600)); mn = await runMain(tab.id); }
    const ok = !!(mn && mn.appSees && mn.appSees !== 'אין פונקציה');
    add(ok, ok ? 'הממשק מזהה את התוסף ✓ (גרסה ' + mn.appSees + ')' : 'הממשק עדיין לא מזהה את התוסף', `מאפיין על <html>: ${mn && mn.attr || 'אין'} · תג meta: ${mn && mn.meta || 'אין'} · התקבלה הודעה: ${mn && mn.seen || 'לא'} · מה שהממשק מחזיר: ${mn && mn.appSees || 'ריק'} · גרסת הממשק בעמוד: ${mn && mn.appVer || 'לא מופיעה'} · הסקריפט הראשי: ${mn && mn.appRan === 'function' ? 'רץ' : 'לא רץ'} · סקריפטים בעמוד: ${mn && mn.scripts}`);
  } catch (e) { add(false, 'בדיקת מה שהממשק רואה נכשלה', errText(e)); }
  await addBgLog();
}
async function addBgLog() {
  try {
    const r = await new Promise((res, rej) => { const t = setTimeout(() => rej(new Error('אין תשובה מה-background (השירות כבוי?)')), 3000);
      chrome.runtime.sendMessage({ type: 'diag-log' }, resp => { clearTimeout(t); chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res(resp); }); });
    const log = (r && r.log) || [];
    add(true, 'ה-background פעיל', log.length ? '' : 'היומן ריק — לא נרשמה שום פעולה הזרקה מאז הטעינה');
    log.forEach(l => { lines.push('  · ' + l); $('checks').insertAdjacentHTML('beforeend', `<span class="sub">· ${l}</span>`); });
  } catch (e) { add(false, 'ה-background לא ענה', errText(e)); }
}

$('inject').onclick = () => run(true);
$('copy').onclick = () => { const t = $('report'); t.style.display = 'block'; t.value = lines.join('\n'); t.select(); try { document.execCommand('copy'); } catch (e) {} };
run(true);
