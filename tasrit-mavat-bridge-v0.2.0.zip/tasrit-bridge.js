// Content script on the tasrit app — bridges between the page and the
// extension. Content scripts run in an isolated JS world (can't call the
// page's functions directly), so we talk to the page through DOM events whose
// `detail` holds only plain strings/JSON (files as base64) — that crosses the
// world boundary reliably.
//
//   page ← 'tasrit-import-files'   {files:[{name,type,b64}]}   (user pressed "שלח" on a mavat page)
//   page → 'tasrit-mavat-request'  {reqId,url,docs,planLabel}  (app loaded a plan by number)
//   page ← 'tasrit-mavat-response' {reqId,ok,files,error,stage}
//
// Presence is announced on <html data-tasrit-bridge="version"> so the app can
// offer "load Table 5 too" only when the extension is installed.
(function () {
  const VERSION = chrome.runtime.getManifest().version;
  document.documentElement.setAttribute('data-tasrit-bridge', VERSION);
  document.dispatchEvent(new CustomEvent('tasrit-bridge-ready', { detail: JSON.stringify({ version: VERSION }) }));

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.type !== 'tasrit-import') return;
    document.dispatchEvent(new CustomEvent('tasrit-import-files', { detail: JSON.stringify({ files: msg.files || [] }) }));
  });

  document.addEventListener('tasrit-mavat-request', (e) => {
    let req = {};
    try { req = typeof e.detail === 'string' ? JSON.parse(e.detail) : (e.detail || {}); } catch (err) {}
    const reply = (obj) => document.dispatchEvent(new CustomEvent('tasrit-mavat-response',
      { detail: JSON.stringify(Object.assign({ reqId: req.reqId }, obj)) }));
    try {
      chrome.runtime.sendMessage({ type: 'mavat-fetch', url: req.url, docs: req.docs, planLabel: req.planLabel }, (resp) => {
        if (chrome.runtime.lastError) { reply({ ok: false, stage: 'extension', error: chrome.runtime.lastError.message }); return; }
        reply(resp || { ok: false, error: 'אין תשובה מהתוסף' });
      });
    } catch (err) {
      // extension was reloaded/updated while this page stayed open
      reply({ ok: false, stage: 'extension', error: 'התוסף עודכן — רעננו את העמוד (F5) ונסו שוב' });
    }
  });
})();
