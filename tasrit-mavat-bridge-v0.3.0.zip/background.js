// Service worker — two flows:
//
// 1. send-to-tasrit (user is on a mavat plan page and presses "שלח"):
//    relay captured documents to a tasrit tab — reuse one if open, else open one.
//
// 2. mavat-fetch (user loaded a plan BY NUMBER in the tasrit app, v0.2.0):
//    open that plan's mavat page in a background tab, ask the panel script there
//    to press mavat's own Table 5 download control, return the file to the
//    requesting tasrit tab, and close the mavat tab.
const TASRIT_URL = 'https://tasrit.vercel.app/';
const TASRIT_MATCH = 'https://tasrit.vercel.app/*';
const MAVAT_PLAN_RE = /^https:\/\/mavat\.iplan\.gov\.il\/SV4\/\d+\/\d+\/\d+/;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  if (msg.type === 'send-to-tasrit') {
    (async () => {
      try {
        const tabId = await getOrOpenTasritTab();
        await sendWithRetry(tabId, { type: 'tasrit-import', files: msg.files });
        await chrome.tabs.update(tabId, { active: true });
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: String((e && e.message) || e) });
      }
    })();
    return true; // async response
  }
  if (msg.type === 'mavat-fetch') {
    fetchFromMavat(msg).then(sendResponse, (e) => sendResponse({ ok: false, stage: 'error', error: String((e && e.message) || e) }));
    return true;
  }
  if (msg.type === 'ping') { sendResponse({ ok: true, version: chrome.runtime.getManifest().version }); return; }
});

async function fetchFromMavat(msg) {
  const url = String(msg.url || '');
  if (!MAVAT_PLAN_RE.test(url)) return { ok: false, stage: 'url', error: 'קישור לא תקין לעמוד תוכנית ב"מידע תכנוני"' };
  let tabId = null;
  try {
    const tab = await chrome.tabs.create({ url, active: false });
    tabId = tab.id;
    await waitForTabComplete(tabId, 45000);
    // The Angular app keeps rendering after 'complete' — the panel script waits
    // for the documents tree itself; here we only wait for its listener to be live.
    const res = await withTimeout(
      sendWithRetry(tabId, { type: 'auto-fetch', docs: msg.docs || ['t5'], planLabel: msg.planLabel || '' }, 40, 500),
      300000, 'תם הזמן להורדה מ"מידע תכנוני"'); // several documents, some large PDFs
    return res || { ok: false, stage: 'error', error: 'לא התקבלה תשובה מעמוד התוכנית' };
  } finally {
    if (tabId != null) { try { await chrome.tabs.remove(tabId); } catch (e) {} }
  }
}

async function getOrOpenTasritTab() {
  const tabs = await chrome.tabs.query({ url: TASRIT_MATCH });
  if (tabs.length) return tabs[0].id;
  const tab = await chrome.tabs.create({ url: TASRIT_URL, active: false });
  await waitForTabComplete(tab.id);
  return tab.id;
}

function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    let timer = null;
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') done();
    }
    function done() {
      chrome.tabs.onUpdated.removeListener(listener);
      if (timer) clearTimeout(timer);
      resolve();
    }
    chrome.tabs.onUpdated.addListener(listener);
    if (timeoutMs) timer = setTimeout(done, timeoutMs); // proceed anyway; retries cover the rest
  });
}

function withTimeout(p, ms, msg) {
  return Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error(msg)), ms))]);
}

// Heavy pages (tasrit's single-file app, mavat's Angular app): the tab's network
// "complete" fires before the content script's listener is live. Retry instead
// of guessing a fixed delay.
async function sendWithRetry(tabId, message, tries = 10, delayMs = 400) {
  let lastErr;
  for (let i = 0; i < tries; i++) {
    try {
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (e) {
      lastErr = e;
      await new Promise((r) => setTimeout(r, delayMs));
    }
  }
  throw lastErr || new Error('שליחה נכשלה');
}
